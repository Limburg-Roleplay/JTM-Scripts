>>> Zet deze lijnen in je ox_inventory, stappen;

ox_inventory --> data --> shops.lua --> voeg de onderstaande regels toe! 

       gangshop = {
        name = 'Gang Blackmarket',
         inventory = { 

            { name = 'weapon_bayonet', price = 105000, },
            { name = 'weapon_switchblade', price = 95000, },
            { name = 'weapon_katana', price = 120000, },
            { name = 'weapon_m1911', price = 200000, },
            { name = 'weapon_smithwesson', price = 210000, },
            { name = 'weapon_meos45', price = 200000, },
            { name = 'weapon_skorp', price = 295000, },
            { name = 'weapon_ump45', price = 345000, },
            { name = 'weapon_ak47', price = 420000, },
            { name = 'weapon_ak47u', price = 380000, },
        }
    },

        gangshopammo = {
        name = 'Ammo Winkel',
         inventory = {
            { name = 'ammo-9', price = 5, },
            { name = 'ammo-shotgun', price = 5, },
            { name = 'ammo-45', price = 5, },
            { name = 'ammo-rifle', price = 5, },
        }
    },

        gangshopattachments = {
        name = 'Attachment Winkel',
         inventory = { 

            { name = 'at_ak47_suppressor', price = 500, },
            { name = 'at_ak47_flashlight', price = 500, },
            { name = 'at_ak47_grip', price = 250, },
            { name = 'at_ak47_scope_1', price = 250, },
            { name = 'at_ak47_clip_drummag', price = 250, },
            { name = 'at_skorp_clip_extended', price = 250, },
        }
    },

        extra = {
        name = 'Extra Winkel',
         inventory = { 

            { name = 'phone', price = 5, },
            { name = 'radio', price = 5, },
            { name = 'gps', price = 5, },
            { name = 'handcuffs', price = 5, },
        }
    },