Config = {}

Config.Keys = {
    ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
    ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
    ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
    ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
    ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
    ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
    ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
    ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
}

Config.Teleports = {
    menus = {
        [1] = {
            coords = vector3(138.97, -762.56, 45.75)
        },
        [2] = { -- Begane grond
            coords = vector3(2154.70, 2921.14, -81.07)
        }
    },

    options = {
        [1] = {
            label = 'Begane Grond', 
            desc = 'Optie 1', 
            coords = vector4(138.97, -762.56, 45.75, 160.11)
        },

        [2] = {
            label = 'Server Ruimte', 
            desc = 'Optie 2', 
            coords = vector4(2154.70, 2921.14, -81.07, 274.13)
        }
    }
}

Config.Locations = {
    -----------Jalisco-------------
    {
        coords = vector3(429.72, 4.63, 91.93),
        job = 'gang_jalisco',
        rank = 6,
        drawText = 'Jalisco Cartel | Management',
        functionDefine = OpenManagement,
    },
    {
        coords = vector3(423.04, -0.36, 91.93),
        job = 'gang_jalisco',
        drawText = 'Omkleden',
        functionDefine = CloakroomMenu,
    },
    {
        coords = vector3(392.2602, -5.9516, 84.9239),
        job = 'gang_jalisco',
        drawText = 'Jalisco Cartel | Opslag', 
        functionDefine = OpenStash,
    },

    -----------Alba-------------
    {
        coords = vector3(1407.34, 1134.71, 117.533),
        job = 'gang_alba',
        rank = 5,
        drawText = 'Albanese Maffia | Management',
        functionDefine = OpenManagement,
    },
    {
        coords = vector3(1393.3624, 1160.6311, 117.5362),
        job = 'gang_alba',
        drawText = 'Omkleden',
        functionDefine = CloakroomMenu,
    },
    {
        coords = vector3(1405.6084, 1160.6622, 117.5195),
        job = 'gang_alba',
        drawText = 'Albanese Maffia | Opslag', 
        functionDefine = OpenStash,
    },
    -----------Akatsuki-------------
    {
        coords = vector3(-644.5555, -1243.7054, 11.5516),
        job = 'gang_akatsuki',
        rank = 6,
        drawText = 'Akatsuki | Management',
        functionDefine = OpenManagement,
    },
    {
        coords = vector3(-648.6654, -1229.4749, 11.5516),
        job = 'gang_akatsuki',
        drawText = 'Omkleden',
        functionDefine = CloakroomMenu,
    },
    {
        coords = vector3(-652.6856, -1230.9316, 11.5516),
        job = 'gang_akatsuki',
        drawText = 'Akatsuki | Opslag', 
        functionDefine = OpenStash,
    },
    -----------GSF-------------
    {
        coords = vector3(1026.4825, -2499.2556, 28.4492),
        job = 'gang_gsf',
        rank = 4,
        drawText = 'Grove Street Families | Management',
        functionDefine = OpenManagement,
    },
    {
        coords = vector3(1020.2408, -2499.2688, 28.4298),
        job = 'gang_gsf',
        drawText = 'Omkleden',
        functionDefine = CloakroomMenu,
    },
    {
        coords = vector3(1011.7309, -2499.3623, 28.3022),
        job = 'gang_gsf',
        drawText = 'Grove Street Families | Opslag', 
        functionDefine = OpenStash,
    },
    -----------Menendez-------------
    {
        coords = vector3(-2587.7107, 1910.9783, 167.4989),
        job = 'gang_menendez',
        rank = 4,
        drawText = 'Menendez Cartel | Management',
        functionDefine = OpenManagement,
    },
    {
        coords = vector3(-2602.7043, 1899.4146, 163.75082),
        job = 'gang_menendez',
        drawText = 'Omkleden',
        functionDefine = CloakroomMenu,
    },
    {
        coords = vector3(-2596.9915, 1926.9719, 167.3148),
        job = 'gang_menendez',
        drawText = 'Menendez Cartel | Opslag', 
        functionDefine = OpenStash,
    },
  
}