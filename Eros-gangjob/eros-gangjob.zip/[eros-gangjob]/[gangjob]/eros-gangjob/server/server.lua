local stash1 = {
    id = 'Persoonlijkeopslag',
    label = 'Persoonlijke opslag',
}

AddEventHandler('onServerResourceStart', function(resourceName)
    if resourceName == 'ox_inventory' or resourceName == GetCurrentResourceName() then
	exports.ox_inventory:RegisterStash(stash1.id, stash1.label, 75, 125000, true)
    end
end)

local stash2 = {
    id = 'opslag_drugs',
    label = 'Opslag drugs',
}

AddEventHandler('onServerResourceStart', function(resourceName)
    if resourceName == 'ox_inventory' or resourceName == GetCurrentResourceName() then
	exports.ox_inventory:RegisterStash(stash2.id, stash2.label, 125, 375000, true)
    end
end)

local stash3 = {
    id = 'opslag_wapens',
    label = 'Opslag wapens',
}

AddEventHandler('onServerResourceStart', function(resourceName)
    if resourceName == 'ox_inventory' or resourceName == GetCurrentResourceName() then
	exports.ox_inventory:RegisterStash(stash3.id, stash3.label, 50, 100000, true)
    end
end)

local stash4 = {
    id = 'opslag_leiding',
    label = 'Opslag leiding',
}

AddEventHandler('onServerResourceStart', function(resourceName)
    if resourceName == 'ox_inventory' or resourceName == GetCurrentResourceName() then
	exports.ox_inventory:RegisterStash(stash4.id, stash4.label, 50, 250000, true)
    end
end)

local stash5 = {
    id = 'opslag_zwartgeld',
    label = 'Opslag zwartgeld',
}

AddEventHandler('onServerResourceStart', function(resourceName)
    if resourceName == 'ox_inventory' or resourceName == GetCurrentResourceName() then
	exports.ox_inventory:RegisterStash(stash5.id, stash5.label, 50, true)
    end
end)