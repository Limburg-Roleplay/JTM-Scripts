local ox_inventory = exports['ox_inventory']
ESX = nil


Citizen.CreateThread(function()
    ESX = exports["es_extended"]:getSharedObject()

	while ESX.GetPlayerData().job == nil or ESX.GetPlayerData().job2 == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(PlayerData)
	ESX.PlayerData = PlayerData
	ESX.PlayerLoaded = true
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(Job)
	ESX.PlayerData.job = Job
	ESX.SetPlayerData('job', Job)
end)

RegisterNetEvent('esx:setJob2')
AddEventHandler('esx:setJob2', function(Job)
	ESX.PlayerData.job2 = Job
	ESX.SetPlayerData('job2', Job)
end)

CloakroomMenu = function()
	local options = {
		[1] = {
			['title'] = 'Persoonlijke kleedkamer',
			['description'] = 'Bekijk je eigen outfits',
            ['icon'] = 'box',
			['event'] = 'eros-gangjob:client:own:cloakroom'
		},
	}
	lib.registerContext({
		id = 'eros-gangjob:check-cloakroom',
		title = 'Gang | Kleedkamer',
		options = options
	})
	
	lib.showContext('eros-gangjob:check-cloakroom')
end

OpenStash = function(type, k)
	local job = ESX.PlayerData.job
	lib.registerContext({
        id = 'eros-gangjob:stash',
		title = job.label..' | Opslag',
        options = {
            {
                title = 'Persoonlijke Opslag',
                description = 'Bekijk de uw persoonlijke opslag',
                icon = 'box',      
                onSelect = function()
					local identifier = ESX.PlayerData.identifier
					--ox_inventory:openInventory('stash', job.name..'_'..identifier)
                        exports.ox_inventory:openInventory('stash', {id='Persoonlijkeopslag', owner=''..job.name..'_'..identifier..''})
				end,
                arrow = true,
            },
            {
                title = 'Drugs Opslag',
                description = 'Bekijk de drugs opslag',
                icon = 'box',    
                onSelect = function()
					--ox_inventory:openInventory('stash', job.name..'_opslag_drugs')
                    exports.ox_inventory:openInventory('stash', {id='opslag_drugs', owner=''..job.name..'_opslag_drugs'})
				end,
                arrow = true,
            },
			{
                title = 'Zwartgeld Opslag',
                description = 'Bekijk de de opslag van het zwartgeld',
                icon = 'box',    
                onSelect = function()
					--ox_inventory:openInventory('stash', job.name..'_opslag_zwartgeld')
                    exports.ox_inventory:openInventory('stash', {id='opslag_zwartgeld', owner=''..job.name..'_opslag_zwartgeld'})
				end,
                arrow = true,
            },
			{
                title = 'Wapens Opslag',
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = 'gun',    
                onSelect = function()
					--ox_inventory:openInventory('stash', job.name..'_opslag_wapens')
                      exports.ox_inventory:openInventory('stash', {id='opslag_wapens', owner=''..job.name..'_opslag_wapens'})
				end,
                arrow = true,
            },
            {   
                title = "Wapen Inkoop",
                description = "Hier kunt uw groepering wapens inkopen",
                menu = "wapeninkoop",
                icon = "gun"
            },
        }
    })
	lib.showContext('eros-gangjob:stash')
end

lib.registerContext(
    {
        id = "wapeninkoop",
        title = "Gang: Winkels",
        options = {
            {
                title = "Wapen Winkel",
                description = "Bekijk alle mogelijke wapensoorten die we hebben in de kluis",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "gangshop"})
                end
            },
            {
                title = "Ammo Winkel",
                description = "Bekijk alle mogelijke ammosoorten die we hebben in de kluis",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "gangshopammo"})
                end
            },
            {
                title = "Attachment Winkel",
                description = "Bekijk alle mogelijke attachmentsoorten die we hebben in de kluis",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "gangshopattachments"})
                end
            },
            {
                title = "Extra Winkel",
                description = "Bekijk alle mogelijke handcuffs die we hebben in de kluis",
                icon = "shop",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "extra"})
                end
            },
            {
                title = 'Ga terug',
                onSelect = function()
                    lib.showContext('eros-gangjob:stash')
                end,
                icon = 'fas fa-arrow-left'
            }
        }
    }
)

OpenManagement = function(type, k)
	local job = ESX.PlayerData.job
	lib.registerContext({
        id = 'eros-gangjob:management',
		title = job.label..' | Management',
        options = {
            {
                title = 'Beheer Leden',
                description = 'Beheer de leden van uw groepering',
                icon = 'gun',    
                onSelect = function()
					exports['frp-jobsmenu']:OpenManagementMenu(ESX.PlayerData.job.name)
				end,
                arrow = true,
            },
			{
                title = 'Leiding Opslag',
                description = 'Beheer de opslag van de gang',
                icon = 'box',     
                onSelect = function()
					--ox_inventory:openInventory('stash', job.name..'_opslag_leiding')
                        exports.ox_inventory:openInventory('stash', {id='opslag_leiding', owner=''..job.name..'_opslag_leiding'})
				end,
                arrow = true,
            },
        }
    })
	lib.showContext('eros-gangjob:management')
end


Citizen.CreateThread(function()
	while not ESX.PlayerLoaded do Wait(0) end
    
    while true do
		local sleep = 500
			for k,v in pairs(Config.Locations) do
				if v.rank == nil then v.rank = 0 end
				if v.rank <= tonumber(ESX.PlayerData.job.grade) and (v.target == nil or v.target == false) and v.job == ESX.PlayerData.job.name then
					local playerPed = PlayerPedId()
					local coords = GetEntityCoords(playerPed)
					local dist = #(coords - v.coords)
					if dist < 2.5 then
							sleep = 0
							if v.drawText ~= nil then
									exports['frp-interaction']:Interaction({r = '154', g = '40', b = '40'}, '[E] - ' .. v.drawText, v.coords, 2.5, GetCurrentResourceName() .. '-action-' .. tostring(k))
									ESX.DrawBasicMarker(v.coords, 154, 40, 40)
								if IsControlJustReleased(0, 38) then
									if v.type == nil then v.type = 'default' end
									v['functionDefine'](v.type, k);
								end
							end
					end
				end
			end
			for k,v in pairs(Config.Locations) do
				if v.drawText == 'Omkleden' and v.job == ESX.PlayerData.job.name then
					local coords = GetEntityCoords(playerPed)
					local dist = #(coords - v.coords)
					if dist <= 20.0 and dist > 1.0 then
						sleep = 0
						ESX.DrawBasicMarker(v.coords, 0, 74, 154)
					elseif dist < 2. then
						sleep = 0
						if v.drawText ~= nil then
							exports['frp-interaction']:Interaction({r = '0', g = '74', b = '154'}, '[E] - ' .. v.drawText, v.coords, 2.5, GetCurrentResourceName() .. '-action-' .. tostring(k))
							ESX.DrawBasicMarker(v.coords, 0, 74, 154)
							if IsControlJustReleased(0, 38) then
								if v.type == nil then v.type = 'default' end
								v['functionDefine'](v.type, k);
							end
						end
					end
				end
			end
		Wait(sleep)
    end
end)

RegisterNetEvent('eros-gangjob:client:own:cloakroom')
AddEventHandler('eros-gangjob:client:own:cloakroom', function()
	exports['frp-clothingmenu']:openSavedOutfits()
end)
