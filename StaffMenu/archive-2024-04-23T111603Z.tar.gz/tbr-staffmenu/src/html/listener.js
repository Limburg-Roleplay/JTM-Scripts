$(function(){
    window.addEventListener("message", (event) => {
        var item = event.data;
        if(item !== undefined && item.type === "ui") {
            if (item.display) {
                console.log("Showing NUI");
                $('#container').show();
                $('#aids')[0].play();
            } else {
                console.log("Hiding NUI");
                $('#container').hide();
                $('#aids')[0].pause();
            }
        }
    });
});
