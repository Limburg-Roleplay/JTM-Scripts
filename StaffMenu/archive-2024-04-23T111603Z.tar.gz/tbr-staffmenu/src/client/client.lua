ESX = nil

TriggerEvent('chat:addSuggestion', '/overheid', 'Stuur een overheids bericht!')
TriggerEvent('chat:addSuggestion', '/staffmenu', 'Open Het StaffMenu')

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

RegisterNetEvent('ninno-adminpanel:open')
AddEventHandler('ninno-adminpanel:open', function(source)
    lib.showContext('ninno_adminmain')
end)


    lib.registerContext({
        id = 'ninno_adminmain',
        title = 'Limburg Staffpanel',
        onExit = function()
        end,
        options = {
            {
                title = 'Server Opties',
                icon = 'user',
                arrow = 'true',
                description = 'Open het server menu.',
                onSelect = function(args)
                    lib.showContext('ninno_servermenu')
                end,
            },
            {
                title = 'Development Opties',
                icon = 'code',
                arrow = 'true',
                description = 'Open het development menu.',
                onSelect = function(args)
                    lib.showContext('ninno_devmenu')
                end,
            },
            {
                title = 'Overige Opties',
                icon = 'skull',
                arrow = 'true',
                description = 'Bekijk alle overige functies van dit admin-systeem.',
                onSelect = function(args)
                    lib.showContext('ninno_overig')
                end,
            },
        }
    })

    lib.registerContext({
        id = 'ninno_servermenu',
        title = 'Limburg | Server Opties',
        onExit = function()
        end,
        options = {
            {
                title = 'Carwipe',
                icon = 'car-alt',
                description = 'Voer een carwipe uit over 60 seconden.',
                event = 'wld:delallveh',
            },
            {
                title = 'Maak Mededeling | Chat',
                icon = 'exclamation-circle',
                description = 'Maak een server mededeling. (Global)',
			    onSelect = function(args)
                    mededelingenmenu()
                end,
            },
        }
    })

    lib.registerContext({
        id = 'ninno_devmenu',
        title = 'Limburg | Development Opties',
        onExit = function()
        end,
        options = {
            {
                title = 'Kopiëer Coördinaten',
                icon = 'window-restore',
                description = 'Kopiëer je huidige locatie in coördinaten.',
                onSelect = function(args)
                    ExecuteCommand('copycoords')
                end,
            },
            {
                title = 'Kopiëer Coördinator - Heading',
                icon = 'far fa-window-restore',
                description = 'Kopiëer je huidige locatie in coördinaten & heading.',
                onSelect = function(args)
                    ExecuteCommand('copycoordsandheading')
                end,
            },
        }
    })

    lib.registerContext({
        id = 'ninno_overig',
        title = 'Limburg | Overige Opties',
        onExit = function()
        end,
        options = {
            {
                title = 'Teleporteer naar Waypoint',
                icon = 'map-marked-alt',
                description = 'Teleporteer naar een locatie.',
                event = 'esx:tpm'
            },
            {
                title = 'Geef Job',
                icon = 'address-book',
                description = 'Geef een willekeurige speler een baan.',
				onSelect = function(args)
                    jobmenu()
                end,
            },
			{
                title = 'Spawn een voertuig',
                icon = 'truck-pickup',
                description = 'Spawn een voertuig in via het admin-menu.',
				onSelect = function(args)
                    voertuigmenu()
                end,
            },
            {
                title = 'Ga naar speler',
                icon = 'fas fa-address-card',
                description = 'Ga naar een willekeurige speler.',
				onSelect = function(args)
                    tpnaar()
                end,
            },
            {
                title = 'Breng speler',
                icon = 'far fa-address-card',
                description = 'Breng een willekeurige speler.',
				onSelect = function(args)
                    tpbreng()
                end,
            },
        }
    })










----------------------------------------------------------------------------
------------------------------ Input Dialog's ------------------------------
----------------------------------------------------------------------------








mededelingenmenu = function(job)
    local input = lib.inputDialog('Limburg Staffpanel', {
                { type = 'input', label = 'Persoon (Wie maakt de mededeling)', placeholder = 'Naam..', required = true, min = 1, max = count },
                { type = 'input', label = 'Maak een mededeling', placeholder = 'Bericht..', min = 1, max = count }
            })
	TriggerEvent('chatMessage', input[1], 'staff', input[2] )
    TriggerServerEvent('ninno-staffpanel:mededeling_sv')
end


voertuigmenu = function(job)
    local input = lib.inputDialog('Limburg Staffpanel', {
                { type = 'input', label = 'Spawn een voertuig in', placeholder = 'Voertuig model..', min = 1, max = count }
            })
    TriggerEvent('esx:spawnVehicle', input[1] )
    TriggerServerEvent('ninno-staffpanel:vehiclespawn')
end

jobmenu = function(job)
    local input = lib.inputDialog('Limburg Staffpanel', {
                { type = 'input', label = 'Speler ID', placeholder = 'ID..', min = 1, max = count },
                { type = 'input', label = 'Baan', placeholder = 'Baan..', min = 1, max = count },
                { type = 'input', label = 'Job Grade', placeholder = 'Grade..', min = 1, max = count }
            })
    ExecuteCommand('setjob ' .. input[1] .. ' ' .. input[2] .. ' ' .. input[3] .. '')
end

tpnaar = function(job)
    local input = lib.inputDialog('Limburg Staffpanel', {
                { type = 'input', label = 'Speler ID', placeholder = 'ID..', min = 1, max = count },
            })
    ExecuteCommand('goto ' .. input[1] .. '')
end

tpbreng = function(job)
    local input = lib.inputDialog('Limburg Staffpanel', {
                { type = 'input', label = 'Speler ID', placeholder = 'ID..', min = 1, max = count },
            })
    ExecuteCommand('tp ' .. input[1] .. '')
end

wereldopschonen = function(job)
    local input = lib.inputDialog('Limburg Staffpanel', {
                { type = 'input', label = 'Speler ID', placeholder = 'ID..', min = 1, max = count },
            })
    ExecuteCommand('dv ' .. input[1] .. '')
end