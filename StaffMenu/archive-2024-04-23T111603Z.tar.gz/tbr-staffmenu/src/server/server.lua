-- Server-side script om adminpanel-gebeurtenissen te verwerken

-- Register chat command to open the admin panel
RegisterCommand('staffmenu', function(source, args)
    local player = source
    TriggerClientEvent('ninno-adminpanel:open', player)
end, false)


-- Gebeurtenis om een mededeling naar alle spelers te sturen
RegisterServerEvent('ninno-staffpanel:mededeling_sv')
AddEventHandler('ninno-staffpanel:mededeling_sv', function(message)
    -- Hier kun je code toevoegen om de mededeling naar alle spelers te sturen
    TriggerClientEvent('chatMessage', -1, 'Admin', {255, 0, 0}, message)
end)

-- Gebeurtenis om een voertuig te spawnen
RegisterServerEvent('ninno-staffpanel:vehiclespawn')
AddEventHandler('ninno-staffpanel:vehiclespawn', function(vehicleModel)
    -- Hier kun je code toevoegen om een voertuig te spawnen
    -- Bijvoorbeeld:
    -- TriggerClientEvent('esx:spawnVehicle', -1, vehicleModel)
end)

-- Gebeurtenis om de baan van een speler in te stellen
RegisterServerEvent('ninno-staffpanel:setjob')
AddEventHandler('ninno-staffpanel:setjob', function(playerId, jobName, jobGrade)
    -- Hier kun je code toevoegen om de baan van de speler in te stellen
    -- Bijvoorbeeld:
    -- TriggerEvent('esx:setJob', playerId, jobName, jobGrade)
end)

-- Voeg hier andere server-side gebeurtenissen toe voor andere adminpanel-opties

