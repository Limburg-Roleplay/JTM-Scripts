fx_version 'cerulean'
author 'JTM-Development'
lua54 'yes'
game 'gta5'

ui_page('src/html/index.html')

files {
    'src/html/style.css',
    'src/html/reset.css',
    'src/html/listener.js',
    'src/html/index.html',
    'src/html/yeet.ogg'
}

server_scripts {
	'@mysql-async/lib/MySQL.lua',
	'@es_extended/locale.lua',
	'src/server/*.lua',
}

shared_scripts {
    '@ox_lib/init.lua',
    '@es_extended/locale.lua',
}

client_scripts {
	'@es_extended/locale.lua',
	'src/client/*.lua',
}