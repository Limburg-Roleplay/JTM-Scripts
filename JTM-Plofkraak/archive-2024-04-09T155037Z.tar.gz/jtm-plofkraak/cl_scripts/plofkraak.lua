local robberyOngoing = false

local c4 = nil

local eventTriggered = false

local MinPolice = Config.MinPolice

Citizen.CreateThread(
    function()
        if ESX.IsPlayerLoaded() then
            ESX.PlayerData = ESX.GetPlayerData()
        end
    end
)

RegisterNetEvent("esx:setJob")
AddEventHandler(
    "esx:setJob",
    function(job)
        ESX.PlayerData.job = job
    end
)

Citizen.CreateThread(function()
    for i = 1, #Config.ATM.Props do
        exports.ox_target:addModel(
            GetHashKey(Config.ATM.Props[i]),
            {
                {
                    distance = 0.8,
                    label = "Start Plofkraak",
                    icon = "fa-solid fa-bomb",
                    onSelect = function(data)
                        print(json.encode(data))
                        ESX.TriggerServerCallback("jtm-plofkraak:jtm-agentencheck",
                            function(IsEnough)
                                if IsEnough then
                                    if exports.ox_inventory:GetItemCount("C4") > 0 then
                                        TriggerServerEvent("jtm-plofkraak:jtm-plofkraakstart", i)
                                    else
                                        exports["frp-notifications"]:Notify("error", "Je hebt geen C4!", 5000)
                                    end
                                else
                                    exports["frp-notifications"]:Notify("error", "Er is niet genoeg politie!", 5000)
                                end
                            end,
                            MinPolice
                        )
                    end
                }
            }
        )
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)
        if robberyOngoing and not placed then
            placed = true
            for i = 1, #Config.ATM.Props do
                exports.ox_target:addModel(
                    GetHashKey(Config.ATM.Props[i]),
                    {
                        {
                            distance = 1,
                            label = "Geld pakken",
                            icon = "fa-solid fa-money-bill-1",
                            onSelect = function(data)
                                if not eventTriggered then -- Check if the event has been triggered
                                    TriggerEvent("jtm-plofkraak:jtm-getmoney", i)
                                    eventTriggered = true -- Set the flag to true
                                else
                                    exports["frp-notifications"]:Notify("error", "Je hebt al Geld gepakt!", 5000) -- Notify the player
                                end
                            end
                        }
                    }
                )
            end
        end
    end
end)


RegisterNetEvent('jtm-plofkraak:jtm-plofkraakmelding')
AddEventHandler('jtm-plofkraak:jtm-plofkraakmelding', function(position)
    if ESX.PlayerData.job.name == 'police' then
        ESX.ShowNotification('error', 'Er is een Plofkraak gestart! Check je map voor de locatie!', 5000)

        blipRobbery = AddBlipForCoord(position.x, position.y, position.z)
        SetBlipSprite(blipRobbery , 161)
        SetBlipScale(blipRobbery , 2.0)
        SetBlipColour(blipRobbery, 1)
        PulseBlip(blipRobbery)
        Wait(30000) -- tijd in miliseconden
        RemoveBlip(blipRobbery)
    end
end)

RegisterNetEvent("jtm-plofkraak:jtm-plofkraakstart")
AddEventHandler(
    "jtm-plofkraak:jtm-plofkraakstart",
    function(PlofkraakId)
        ESX.TriggerServerCallback("jtm-plofkraak:jtm-agentencheck",
            function(IsEnough)
                if IsEnough then
                    local playerPed = GetPlayerPed(-1)

                    local location = GetEntityCoords(playerPed)

                    getThermietemote()
                    exports["frp-progressbar"]:Progress(
                        {
                            name = "C4 Planten en Activeren",
                            duration = Config.ThermietTimer * 1000,
                            label = "C4 Planten en Activeren",
                            useWhileDead = false,
                            canCancel = true,
                            controlDisables = {
                                disableMovement = false,
                                disableCarMovement = true,
                                disableMouse = false,
                                disableCombat = true
                            }
                        }
                    )
                    Citizen.Wait(Config.ThermietTimer * 1000)
                    ClearPedTasksImmediately(PlayerPedId())

                    Wait(100)
                    RequestNamedPtfxAsset("scr_josh3")
                    while not HasNamedPtfxAssetLoaded("scr_josh3") do
                        Wait(1)
                    end
                    UseParticleFxAssetNextCall("scr_josh3")
                    AddExplosionWithUserVfx(
                        location.x,
                        location.y,
                        location.z,
                        26,
                        "EXP_VFXTAG_TRN4_DYNAMITE",
                        100000.0,
                        true,
                        false,
                        1
                    )
                    PlaySoundFromCoord(-1, "MAIN_EXPLOSION_CHEAP", location.x, location.y, location.z, 0, 0, 0, 0)
                    StartParticleFxNonLoopedAtCoord(
                        "scr_josh3_explosion",
                        location.x,
                        location.y,
                        location.z,
                        0.0,
                        0.0,
                        0.0,
                        7.0,
                        false,
                        false,
                        false,
                        0
                    )
                    DeleteEntity(c4)
                    TriggerServerEvent("jtm-plofkraak:flowmoneysv", location)
                    robberyOngoing = true
                else
                    exports["frp-notifications"]:Notify("error", "Er is niet genoeg politie!", 5000)
                end
            end,
            MinPolice
        )
    end
)

RegisterNetEvent("jtm-plofkraak:jtm-getmoney")
AddEventHandler(
    "jtm-plofkraak:jtm-getmoney",
    function(PlofkraakId)
        local playerPed = GetPlayerPed(-1)

        getMoneyemote()
        exports["frp-progressbar"]:Progress({
            name = "Geld Pakkken",
            duration = Config.Moneypicktimer * 1000,
            label = "Geld Pakken",
            useWhileDead = false,
            canCancel = false,
            controlDisables = {
                disableMovement = true,
                disableCarMovement = true,
                disableMouse = false,
                disableCombat = true
            }
        })
        Citizen.Wait(Config.Moneypicktimer * 1000)
        ClearPedTasksImmediately(PlayerPedId())
        TriggerServerEvent("jtm-plofkraak:jtm-getmoney", i)
    end
)

RegisterNetEvent("jtm-plofkraak:jtm-plofkraakstart")
AddEventHandler(
    "jtm-plofkraak:jtm-plofkraakstart",
    function(PlofkraakId)
        StartRobbery(PlofkraakId)
        robberyOngoing = true
    end
)

RegisterNetEvent("jtm-plofkraak:jtm-plofkraakstop")
AddEventHandler(
    "jtm-plofkraak:jtm-plofkraakstop",
    function(PlofkraakId)
        robberyOngoing = false
    end
)

function StartRobbery(PlofkraakId)
    robberyOngoing = true
end

function  getMoneyemote()
    local playerPed = PlayerPedId()
    TaskPlayAnim(PlayerPedId(), "anim@amb@business@standing@base", "base", 8.0, -8.0, -1, 1, 0, false, false, false)
    local animDict = "mini@repair"
    local animName = "fixing_a_ped"

    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Wait(100)
    end

    TaskPlayAnim(playerPed, animDict, animName, 8.0, -8.0, -1, 0, 0, false, false, false)
end


function getThermietemote()
    local playerPed = PlayerPedId() -- Get the player's ped
    local rot, pos = GetEntityRotation(playerPed), GetEntityCoords(playerPed)
    local scene = NetworkCreateSynchronisedScene(pos.x, pos.y, pos.z, rot.x, rot.y, rot.z, 2, 0, 0, 1065353216, 0, 1.3)
    local bag = CreateObject("hei_p_m_bag_var22_arm_s", pos.x, pos.y, pos.z, true, true, false)
    SetPedComponentVariation(playerPed, 5, -1, 0, 0)
    SetEntityCollision(bag, 0, 1)
    c4 = CreateObject("ch_prop_ch_explosive_01a", pos.x, pos.y, pos.z + 0.2, 1, 1, 1)
    SetEntityCollision(c4, 0, 1)
    AttachEntityToEntity(c4, playerPed, GetPedBoneIndex(playerPed, 28422), 0, 0, 0, 0, 0, 180.0, 1, 1, 0, 1, 1, 1)
    TaskPlayAnim(PlayerPedId(), "anim@amb@business@standing@base", "base", 8.0, -8.0, -1, 1, 0, false, false, false)
    local animDict = "anim@heists@ornate_bank@thermal_charge"
    local animName = "thermal_charge"

    NetworkAddPedToSynchronisedScene(
        playerPed,
        scene,
        "anim@heists@ornate_bank@thermal_charge",
        "thermal_charge",
        1.5,
        -4.0,
        1,
        16,
        1148846080,
        0
    )
    NetworkAddEntityToSynchronisedScene(
        bag,
        scene,
        "anim@heists@ornate_bank@thermal_charge",
        "bag_thermal_charge",
        4.0,
        -8.0,
        1
    )
    NetworkStartSynchronisedScene(scene)

    -- Request the animation dictionary
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Wait(100)
    end

    -- Play the animation
    TaskPlayAnim(playerPed, animDict, animName, 8.0, -8.0, -1, 0, 0, false, false, false)

    Wait(4000)
    DetachEntity(c4, 1, 1)
    FreezeEntityPosition(c4, 1)
    SetEntityCollision(c4, 0, 1)
    DeleteEntity(bag)
    SetPedComponentVariation(playerPed, 5, 45, 0, 0)
end

RegisterNetEvent("jtm-plofkraak:flowmoney")
AddEventHandler(
    "jtm-plofkraak:flowmoney",
    function(coords)
        -- Load the particle dictionary
        local dict = "scr_xs_celebration"
        local name = "scr_xs_money_rain_celeb" -- Example particle name, use the actual name you find

        RequestNamedPtfxAsset(dict) -- Request the particle asset
        while not HasNamedPtfxAssetLoaded(dict) do
            Wait(1)
            RequestNamedPtfxAsset(dict)
        end

        UseParticleFxAssetNextCall(dict)
        local effect =
            StartParticleFxLoopedAtCoord(
            name,
            coords.x,
            coords.y,
            coords.z - 0.3,
            0.0,
            0.0,
            0.0,
            1.2,
            false,
            false,
            false,
            false
        )
        -- Stop the effect after 10 seconds
        Wait(20000)
        StopParticleFxLooped(effect, 0)
    end
)
