Config = {}

Config.MinPolice = 0 -- Minimale politie om de plofkraak te starten

Config.ThermietTimer = 10 -- Tijd in seconden

Config.Moneypicktimer = 10 -- Tijd in seconden

Config.RobberyCooldown = 1800000 -- Cooldown tijd in milliseconden voor plofkraak

Config.PlofkraakMoney = {min = 5000, max = 10000} -- de hoeveelheid cash dat iemand uit een plofkraak krijgt

Config.ATM = {
    ['Props'] = {
        'prop_atm_03',
        'prop_fleeca_atm',
        'prop_atm_02'
    }
}