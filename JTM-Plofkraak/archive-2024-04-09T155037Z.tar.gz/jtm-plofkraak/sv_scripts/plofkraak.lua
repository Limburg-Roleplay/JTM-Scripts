ESX = exports["es_extended"]:getSharedObject()

local robbedLately = false

local cooldown = Config.RobberyCooldown

RegisterServerEvent("jtm-plofkraak:jtm-plofkraakstart")
AddEventHandler("jtm-plofkraak:jtm-plofkraakstart", function(PlofkraakId)
    if robbedLately then
        TriggerClientEvent("frp-notifications:client:notify", source, "error", "Er is recentelijk een Plofkraak geweest, kom later terug!", 5000)
        return
    end

    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem("c4", 1)

    local playerCoords = GetEntityCoords(GetPlayerPed(source))

    TriggerClientEvent('jtm-plofkraak:jtm-plofkraakmelding', -1, playerCoords)
    TriggerClientEvent("jtm-plofkraak:jtm-plofkraakstart", xPlayer.source, PlofkraakId)

    robbedLately = true
    Citizen.Wait(cooldown)
    robbedLately = false
end)

RegisterServerEvent("jtm-plofkraak:jtm-getmoney")
AddEventHandler("jtm-plofkraak:jtm-getmoney",
    function(newCash)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    local xPlayer = ESX.GetPlayerFromId(source)

    local newCash = math.random(Config.PlofkraakMoney.min, Config.PlofkraakMoney.max)

    xPlayer.addAccountMoney("black_money", newCash)

    TriggerClientEvent("frp-notifications:client:notify", xPlayer.source, "info", "Je hebt €" .. newCash .. " verdiend met de plofkraak!", "5000")

end)




RegisterServerEvent("jtm-plofkraak:jtm-plofkraakstop")
AddEventHandler(
    "jtm-plofkraak:jtm-plofkraakstop",
    function(PlofkraakId)
        TriggerClientEvent("jtm-plofkraak:jtm-plofkraakstop", -1, PlofkraakId)
    end
)

ESX.RegisterServerCallback("jtm-plofkraak:jtm-agentencheck", function(source, cb, minCops)
    local copsOnDuty = 0

    local Players = ESX.GetPlayers()

    for i = 1, #Players do
        local xPlayer = ESX.GetPlayerFromId(Players[i])

        if xPlayer["job"]["name"] == "police" then
            copsOnDuty = copsOnDuty + 1
        end
    end

    if copsOnDuty >= minCops then
        cb(true)
    else
        cb(false)
    end
end)

RegisterNetEvent("jtm-plofkraak:flowmoneysv")
AddEventHandler(
    "jtm-plofkraak:flowmoneysv",
    function(coords)
        TriggerClientEvent("jtm-plofkraak:flowmoney", -1, coords)
    end
)
