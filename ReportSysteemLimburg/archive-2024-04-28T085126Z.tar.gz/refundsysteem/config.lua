Config              = {}

Config.Locale = 'nl'

Config.webhookurl   = 'https://discord.com/api/webhooks/1184276921421410464/waTXLo9CWsXauVAOy3UVoP61oJk8d0gO49eEfQZ6_L2rSW6SDjmWRX2h1lUSBXs-bbyW'
Config.refundWebhookurl = 'https://discord.com/api/webhooks/1184276426258653245/S5FVQsrxw_3yKCCG3vmndIg3zMN9m1uWaxoJhR-LhyqnKabbQl05lmSM8ZjKPIFlzvHR'
Config.imgurl           = ''
Config.useDiscord = true
Config.defaultUserGroup = 'user'
Config.enableRefunds = true
Config.logDatabase = true

Config.color = {
    report = 16711680,
    reply = 16748800,
    refund = 65301
}