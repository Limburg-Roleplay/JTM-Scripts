ESX = exports["es_extended"]:getSharedObject()

RegisterCommand('giverefund', function(source, args, rawCommand)
    if source == 0 or IsPlayerAceAllowed(source,'xadmin.all') or IsPlayerAceAllowed(source,'xadmin.refunds') then

    if #args < 3 then
        print('Usage: /giverefund [player steam id] [item] [item-count]')
        return
    end

    local steamID, item, itemCount = table.unpack(args)
    MySQL.Async.execute('INSERT INTO user_refunds (steamID, item, itemCount) VALUES (@steamID, @item, @itemCount)', {
        ['@steamID'] = steamID,
        ['@item'] = item,
        ['@itemCount'] = itemCount
    }, function(rowsChanged)
        if rowsChanged > 0 then
			local user = (source > 0) or "console"
			local playerName = (source > 0) and GetPlayerName(source) or "console"
			TriggerEvent('td_logs:sendLog', 'https://discord.com/api/webhooks/1184276426258653245/S5FVQsrxw_3yKCCG3vmndIg3zMN9m1uWaxoJhR-LhyqnKabbQl05lmSM8ZjKPIFlzvHR', user, {title = playerName .. " heeft zojuist een refund geplaatst.", desc = "Betreft: " .. itemCount .. "x " .. item})
                      
			 print('Refund succesvol toegekent.')
        else
            print('Kon geen refunds vinden.')
        end
    end)
            else
            	print('Geen permissie.')
            end
end, true)

RegisterCommand('claimrefunds', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    local playerIdentifiers = GetPlayerIdentifiers(source)
        local steamID = nil

        for _, identifier in ipairs(playerIdentifiers) do
            if string.sub(identifier, 1, 5) == "steam" then
                steamID = identifier
                break
            end
        end
    MySQL.Async.fetchAll('SELECT * FROM user_refunds WHERE steamID = @steamID', {
        ['@steamID'] = steamID
    }, function(results)
        if #results == 0 then
            print('Je hebt geen refunds om te claimen.')
            return
        end

        for _, refund in ipairs(results) do
            local item = refund.item
            local itemCount = refund.itemCount

            -- Assuming you have a function to add items to a player's inventory, it might look something like this:
            xPlayer.addInventoryItem(item, itemCount)
                print('Refund toegekent.')
				TriggerEvent('td_logs:sendLog', 'https://discord.com/api/webhooks/1184276426258653245/S5FVQsrxw_3yKCCG3vmndIg3zMN9m1uWaxoJhR-LhyqnKabbQl05lmSM8ZjKPIFlzvHR', source, {title = GetPlayerName(source) .. " heeft zojuist een refund geclaimed.", desc = "Betreft: " .. itemCount .. "x " .. item})
                        -- Mark the refund as claimed
            MySQL.Async.execute('DELETE FROM user_refunds WHERE id = @id', {
                ['@id'] = refund.id
            })

            
        end

        xPlayer.showNotification('All refunds claimed.')
    end)
end)
RegisterCommand('report',function(source, args, rawCommand)
	local reason = string.gsub(rawCommand, 'report ', '')
	local playerName = GetPlayerName(source)
	if xwebhook ~= 'none' then
		PerformHttpRequest(xwebhook, function(err, text, headers) end, 'POST', json.encode({content = '**Report**```Player:'..playerName..'\nReason:'..reason..'```'}), { ['Content-Type'] = 'application/json' })
	end
	for _, playerId in ipairs(GetPlayers()) do
		if IsPlayerAceAllowed(playerId,'xadmin.all') or IsPlayerAceAllowed(playerId,'xadmin.report') or playerId == source then
			TriggerClientEvent("chatMessage", playerId, "Report van " .. playerName,"primary", "[".. source .. "]: " .. reason)
		end
	end
    TriggerClientEvent("chatMessage", source, "Report Gestuurd!","primary", "Je report is succesvol gestuurd.")
end)