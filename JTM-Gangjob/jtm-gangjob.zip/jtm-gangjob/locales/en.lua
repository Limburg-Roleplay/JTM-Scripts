Locales['en'] = {
  ['id_card'] = 'ID kaart',
  ['driver_license'] = 'Rijbewijs',
  ['search'] = 'Fouilleren',
  ['handcuff'] = 'Boeien',
  ['uncuff'] = 'Ontboeien',
  ['drag'] = 'Escort',
  ['put_in_vehicle'] = 'In voertuig plaatsen',
  ['out_the_vehicle'] = 'Uit voertuig slepen',
  ['no_players_nearby'] = 'Er is geen speler in de buurt !',
  ['being_searched'] = 'Je wordt  ~y~gefouilleerd~s~',
}
