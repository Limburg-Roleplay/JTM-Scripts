Locales['en'] = {
  ['no_handcuffs'] = 'Geen handboeien op zak ?',
  ['no_player'] = 'Er zijn geen personen in de buurt',
}