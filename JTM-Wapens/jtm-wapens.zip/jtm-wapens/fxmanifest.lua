fx_version 'adamant'

lua54 'yes'
game 'gta5'

author 'JTM Development'
description 'Fingerprint Script'

version '1.2.0'
shared_scripts { '@es_extended/imports.lua', '@ox_lib/init.lua'}
server_scripts {
	'@oxmysql/lib/MySQL.lua',
	'sv_scripts/*.lua',
}

client_scripts {
	'@es_extended/locale.lua',
	'cl_scripts/*.lua',
}