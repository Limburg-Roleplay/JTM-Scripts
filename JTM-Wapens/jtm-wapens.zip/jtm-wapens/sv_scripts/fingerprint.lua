ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent('jtm-fingerprintinfo')
AddEventHandler('jtm-fingerprintinfo', function()
    local source = source -- The source of the event
    local xPlayer = ESX.GetPlayerFromId(source)

    -- Check if the player is in the police job
    if xPlayer.getJob().name == 'police' then 
        local nearestPlayerId = GetNearestPlayerId(source)
        if nearestPlayerId ~= -1 then
            local infotarget = ESX.GetPlayerFromId(nearestPlayerId)
            if infotarget then
            TriggerClientEvent('chatMessage', source, 'fingerprint Scan Voltooid!', 'fingerprint', "Naam: ".. infotarget.getName() .. ", Geboortedatum: " .. (infotarget.get('dateofbirth') or "Niet bekend") .. ", Geslacht: " .. (infotarget.get('sex') or "Niet bekend"))

            else
                TriggerClientEvent('chatMessage', source, 'Informatie', 'error', "Persoon niet gevonden!")
            end
        else
            TriggerClientEvent("frp-notifications:client:notify", source, "error", "Er is niemand in de buurt!", 3000)
        end
    else
        TriggerClientEvent("frp-notifications:client:notify", source, "error", "Je hebt hier niet de juiste permissies voor!", 3000)
    end
end)

function GetNearestPlayerId(source)
    local players = GetNearbyPlayers(source, 10) -- Adjust radius as needed
    local closestDistance = -1
    local closestPlayer = -1
    local sourceCoords = GetEntityCoords(GetPlayerPed(source))
    for _, playerId in ipairs(players) do
        if playerId ~= source then -- Exclude the source player
            local targetPed = GetPlayerPed(playerId)
            local targetCoords = GetEntityCoords(targetPed)
            local distance = #(sourceCoords - targetCoords)
            if closestDistance == -1 or distance < closestDistance then
                closestPlayer = playerId
                closestDistance = distance
            end
        end
    end
    return closestPlayer
end

function GetNearbyPlayers(playerId, radius)
    local nearbyPlayers = {}
    local playerPed = GetPlayerPed(playerId)
    local playerCoords = GetEntityCoords(playerPed)

    -- Iterate through all players
    for _, id in ipairs(GetActivePlayers()) do
        local targetPed = GetPlayerPed(id)
        if targetPed ~= playerPed then
            local targetCoords = GetEntityCoords(targetPed)
            local distance = #(playerCoords - targetCoords)
            if distance <= radius then
                table.insert(nearbyPlayers, id)
            end
        end
    end

    return nearbyPlayers
end
