Config = {}

-- Duur van de vingerafdrukscan in seconden
Config.fingerprint = 10
