local Config = {} -- Define and initialize the Config variable

-- Duration of the fingerprint scan in seconds
Config.fingerprint = 3

-- Add more configuration settings if needed

exports.ox_target:addBoxZone({
    coords = vector3(-1096.3188, -814.0187, 5.3862),
    size = vector3(2, 2, 2),
    rotation = 45,
    options = {
        {
            name = "Fingerprint Scan",
            label = "Fingerprint Scan uitvoeren",
            icon = "fa-solid fa-computer",
            debug = drawZones,
            onSelect = function()
                TriggerEvent("jtm-fingerprintscantimer")
            end
        }
    }
})

RegisterNetEvent("jtm-fingerprintscantimer")
AddEventHandler("jtm-fingerprintscantimer", function()
    exports["frp-progressbar"]:Progress({
        name = "Persoon aan het scannen!",
        duration = Config.fingerprint * 1000,
        label = "Persoon aan het scannen!",
        useWhileDead = false,
        canCancel = false,
        controlDisables = {
            disableMovement = true,
            disableCarMovement = true,
            disableMouse = false,
            disableCombat = true
        }
    })
    Citizen.Wait(Config.fingerprint * 1000)
    TriggerServerEvent("jtm-fingerprintinfo") -- Triggered immediately after the progress bar starts
end)
