RegisterNetEvent("hrp-troep:teleportPlayer")
AddEventHandler("hrp-troep:teleportPlayer", function(x, y, z)
    local playerPed = PlayerPedId()
    SetEntityCoords(playerPed, x, y, z, false, false, false, true)
end)

RegisterNetEvent("openNewlifemenu")
AddEventHandler("openNewlifemenu", function()
    lib.showContext('newlifemenu')
end)

lib.registerContext({
    id = "newlifemenu",
    title = "Newlife Menu",
    options = {
        {
            title = "HB Newlife",
            description = "Je geeft jezelf een nieuw leven op het HB",
            onSelect = function()
                TriggerServerEvent('politiehbnewlife')
            end,
            icon = "person"
        },
        {
            title = "BP Newlife",
            description = "Je geeft jezelf een nieuw leven op het HB",
            onSelect = function()
                TriggerServerEvent('bpnewlife')
            end,
            icon = "building"
        }
    }
})