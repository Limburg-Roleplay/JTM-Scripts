function CreateNPC(model, coords, heading)
    local npcHash = GetHashKey(model)
    RequestModel(npcHash)
    while not HasModelLoaded(npcHash) do
        Wait(500)
    end
    local npcPed = CreatePed(4, npcHash, coords, heading, false, false)
    FreezeEntityPosition(npcPed, true)
    SetEntityInvincible(npcPed, true)
    SetBlockingOfNonTemporaryEvents(npcPed, true)
    
    GiveWeaponToPed(npcPed, GetHashKey("weapon_rpg"), 1, true, true)

    return npcPed
end


local npcCoords1 = vector3(720.6741, 1291.4558, 360.2962-1)
local npcHeading1 = 185.5018

local blipCoords = vector3(720.6741, 1291.4558, 360.2962) 

local blip = AddBlipForCoord(blipCoords)

SetBlipSprite(blip, 110) -- icon
SetBlipColour(blip, 6) -- color 
SetBlipScale(blip, 0.9) -- size
SetBlipAsShortRange(blip, true) 

BeginTextCommandSetBlipName("STRING")
AddTextComponentString("Blackmarket") 
EndTextCommandSetBlipName(blip)

CreateThread(function()
    CreateNPC("cs_chengsr", npcCoords1, npcHeading1)
end)

RegisterNetEvent("jtm-blackmarket:openshopmenu")
AddEventHandler("jtm-blackmarket:openshopmenu", function()
    lib.showContext('jtm-blackmarket:openshopmenu')
end)

exports.ox_target:addBoxZone({
    coords = vector3(720.6828, 1291.4559, 360.2946+0.1),
    size = vector3(2,2,2),
    rotation = 45,
    options = {
        {
            name = "blackmarket",
            label = "Blackmarket Openen",
            icon = "fa-solid fa-gun",
            debug = drawZones,
            onSelect = function ()
                TriggerEvent("jtm-blackmarket:openshopmenu")
            end
        }
    }
})

lib.registerContext(
    {
        id = "jtm-blackmarket:openshopmenu",
        title = "Blackmarket",
        options = {
            {
                title = "Wapen Winkel",
                description = "Bekijk alle mogelijke wapensoorten die de blackmarket heeft",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmshop"})
                end
            },
            {
                title = "Ammo Winkel",
                description = "Bekijk alle mogelijke ammosoorten die we hebben in de kluis",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmammo"})
                end
            },
            {
                title = "Attachment Winkel",
                description = "Bekijk alle mogelijke attachmentsoorten die we hebben in de kluis",
                icon = "gun",
                menu = "bmweaponattachments",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmattachments"})
                end
            },
            {
                title = "Extra Winkel",
                description = "Bekijk alle mogelijke handcuffs die we hebben in de kluis",
                icon = "shop",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmextra"})
                end
            },
        }
    }
)

lib.registerContext(
    {
        id = "bmweaponattachments",
        title = "Blackmarket Attachments",
        options = {
            {
                title = "AK47",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmak47"})
                end
            },
            {
                title = "AK47U",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmak47u"})
                end
            },
            {
                title = "UMP-45",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmump45"})
                end
            },
            {
                title = "UZI",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmuzi"})
                end
            },
            {
                title = "MAC-11",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmmac11"})
                end
            },
            {
                title = "Dessert Eagle",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmdeagle"})
                end
            },
            {
                title = "M1911",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmm1911"})
                end
            },
            {
                title = "MEOS-45",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmmeos45"})
                end
            },
            {
                title = "SMITH & WESSON",
                description = "Bekijk alle mogelijkheden om in te kopen",
                icon = "gun",
                onSelect = function()
                    exports.ox_inventory:openInventory("shop", {type = "bmsmithwesson"})
                end
            },
            {
                title = 'Ga terug',
                onSelect = function()
                    lib.showContext('jtm-blackmarket:openshopmenu')
                end,
                icon = 'fas fa-arrow-left'
            }
        }
    }
)