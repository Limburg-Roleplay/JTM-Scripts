ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) 
    ESX = obj 
end)

RegisterServerEvent('jtm-blackmarket:openshopmenu')
AddEventHandler('jtm-blackmarket:openshopmenu', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
end)
